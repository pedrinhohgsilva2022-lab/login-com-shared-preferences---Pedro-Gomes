package com.miguel.etim_pam1_pedrogomes_sharedpreferences;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText nome, email, senha;
    Button entrar, novo;
    CheckBox lembrar;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        preferences = getSharedPreferences("login", 0);

        String pNome = preferences.getString("Nome", "");
        String pEmail = preferences.getString("Email", "");
        String pSenha = preferences.getString("senha", "");

        if (!pNome.isEmpty() && !pEmail.isEmpty() && !pSenha.isEmpty()) {
            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            startActivity(intent);
        }

        initComponents();

        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validarDados()) {
                    if (lembrar.isChecked()) {
                        preferences = getPreferences("login" , 0);
                        SharedPreferences.editor dados = preferences.edit();
                        dados.putString ("Nome" , nome.getText().toString());
                        dados.putString ("Email", email.getText().toString());
                        dados.putString ("Senha" , senha.getText().toString());
                        dados.commit();
                    }
                }
            }
        });

        private void initComponents() {
            nome = findViewById(R.id.edt_nome);
            email = findViewById(R.id.edt_email);
            senha = findViewById(R.id.edt_nome);
            entrar = findViewById(R.id.btn_entrar);
            novo = findViewById(R.id.btn_novo);
            lembrar = findViewById(R.id.box);
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}